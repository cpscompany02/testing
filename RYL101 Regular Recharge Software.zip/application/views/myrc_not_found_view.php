<?php

if(!(isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER']) && stristr($_SERVER['HTTP_REFERER'],$_SERVER['HTTP_HOST'])))
{
redirect('');
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge" /><![endif]-->
    <title><?php

$text = $_SERVER["REQUEST_URI"];
$string = str_replace('/', '', $text );
 $string = str_replace('-', ' ', $string );
echo $foo = ucwords($string);
 ?></title>
    <meta name="description" content="">


   <?php include('app_css.php'); ?>
</head>

<body>

<?php include('myrc_menu.php'); ?>

<div id="pageTitle" class="bg--overlay" >
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="section-title">
                        <h2><?php echo $foo; ?></h2>
                    </div>
                </div>
                
                <div class="col-md-6">
                    
                </div>
            </div>
        </div>
    </div>

   <div class="container">
        <br>
        

        <div class="content">

            <p>My RC is direct service provider to provide best <?php echo $string; ?> in India, We are giving high margin with 99% Service up time.
            </p>
<hr>

<p>If you are searching  <?php echo $string; ?> for your business, and want to run your business with your brand name then we will help you to provide best <?php echo $string; ?> through online </p>
 <hr>
            <p><?php echo $foo; ?> can be integreted in b2b and B2c Portal where you can use multiple services in single URL and the wallet will be same, you dont need to maintain separately . Start more income by refering to our website , Resell our services and earn referral income upto 50%, </p>

<hr>
<p><?php echo $foo; ?> is the best option to earn passive income. Work as admin and Join Master distributors, Distributors, Retailer or agent. Collect any amount as a franchise or agency charge against <?php echo $foo; ?></p>

        </div>

<b>To Get <?php echo $foo; ?> please register with us, Instant account activation</b>
<hr>
<a href="register" class="btn btn-lg btn-custom" role="button" >Register</a>

<br />
    </div>

    <br>

</div>







<?php include('bottom.php'); ?>
<?php include('footer.php'); ?>
<?php include('app_js.php'); ?>

  
  

</body>
</html>
