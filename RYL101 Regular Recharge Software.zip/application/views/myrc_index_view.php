<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge" /><![endif]-->
    <title>My RC- Recharge Software & API</title>
    <meta name="description" content="">


   <?php include('app_css.php'); ?>
</head>

<body>

<?php include('myrc_menu.php'); ?>

<?php include('single_banner.php'); ?>

<?php include('feature_services.php'); ?>
<?php include('faq.php'); ?>
<?php include('testimonial.php'); ?>
<?php include('bottom.php'); ?>
<?php include('footer.php'); ?>
<?php include('app_js.php'); ?>

  
  

</body>
</html>
