<?php
	$str_query = "select * from tblservice where service_id = '6'";
		
		
		$result_md = $this->db->query($str_query);	
			for($i=0; $i<$result_md->num_rows(); $i++)
		{
		      $status = $result_md->row($i)->service_name;
		      
		      if($status == "expired"){
		      
		      echo "<h1>YOUR SERVER HAS BEEN EXPIRED, PLEASE CONTACT SUPPORT FOR RENEWAL"; exit;
		      }
		}
		?>

<?php $this->load->library('encrypt');?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">

    <title>Login</title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    
    <meta name="description" content="Login Area">
    <meta name="author" content="">
<?php include("app_css.php"); ?>
   
    	<script type="text/javascript">
   function getId(id) { 
       return document.getElementById(id); 
   } 
   function validation() { 
       getId("btnLogin").style.display="none"; 
       getId("wait_tip").style.display=""; 
       return true; 
   } 
</script>

<style>
body  {
  background-image: url("rcpanel.com.jpeg");
  background-color: #cccccc;
}
</style>
</head>
<body>
 
    <!-- FakeLoader Start -->
    <div id="fakeLoader"></div>
    <!-- FakeLoader End -->
    
    <!-- Menu Area Start -->
    
   
    <!-- Menu Area End -->


  
  
    <!-- Page Title Area Start -->
   
    <!-- Page Title Area End -->
    <div class="container">
        <br />
        
        <br />
        <br />
        <br />
        
         <div class="col-md-4 col-md-offset-4 ">
             
        <div class="text-center">
                        <a href=""><img src="images/logo.png" class="rounded" width="auto" height="55"></a>
                    </div>
         
    <div class="panel panel-primary">
      <div class="panel-heading">Welcome to <?php echo $_SERVER['SERVER_NAME'];?> Login Panel</div>
      <div class="panel-body"><div class="row">
                    <div class="form-group col-xs-12">
        
            <div data-form-validation="true">
                <form novalidate="novalidate" action="<?php echo base_url()."login"; ?>" method="post" id="login_form" onsubmit="return validation();">
                
                <div>
                   <?php
                   if($this->session->flashdata('message')){
  echo "<br /><div class='alert alert-danger fade in'>".$this->session->flashdata('message')."</div>";} 

    if ($message != ''){echo "<div class='alert alert-danger' style='color:#F00;'>".$message."</div>"; }?>

    
                  </div>
                <div class="form-group">
                             <label for="loginEmail">Mobile Number *</label> <br />
                        <input id="username" name="username" class="form-control" placeholder="Registered Mobile" type="text" value="<?php if(isset($_COOKIE['username'])) echo $_COOKIE['username']; ?>">
                        </div>
                    <div class="form-group">
                        <label for="loginPassword">Password *</label> <br />
                        <input id="password" name="password" class="form-control" placeholder="Password" value="<?php  $this->load->library('encrypt');
                         $pass = $_COOKIE['password'];
                        
                        $pass3 = $this->encrypt->decode($pass);
                        if(isset($_COOKIE['username'])) echo "$pass3"; ?>" type="password">
                        </div>
                    <div class="checkbox">
    <label><input type="checkbox" name="remember_me" <?php if(isset($_COOKIE['remember_me'])) {
		echo 'checked="checked"';
	}
	else {
		echo '';
	}
	?> >Remember</label>
  </div>
                <input type="submit" class="btn btn-primary" value="Sign In" name="btnLogin" id="btnLogin" /><span id="wait_tip" style="display:none;"> Please wait...<img src="images/ajax-loader2.gif"
           id="loading_img"/></span> <a href="forget" class="btn btn-warning" role="button">Reset Password</a>
           <br />
           
          
                
                </div>
               
          </form>

            <form action="#" method="post" id="pass_form" style="display:none">
                <input placeholder="Your email address" type="text">
                                   
                              </form>

            <form action="#" method="post" id="reg_form" style="display:none">
                
                    <input placeholder="Username" type="text">
                       <input placeholder="Password" type="text">
                       <input placeholder="Your email address" type="text">
                        
            </form>
            </div>
        </div>
    </div></div></div>
    </div>
    </div>
    <!-- Login Area End -->

   
  
    
   

    <?php include("app_js.php"); ?>
    
     <script>
            $(document).ready(function(){

                //* boxes animation
                form_wrapper = $('.login_box');
                function boxHeight() {
                    form_wrapper.animate({ marginTop : ( - ( form_wrapper.height() / 2) - 24) },400);
                };
                form_wrapper.css({ marginTop : ( - ( form_wrapper.height() / 2) - 24) });
                $('.linkform a,.link_reg a').on('click',function(e){
                    var target  = $(this).attr('href'),
                    target_height = $(target).actual('height');
                    $(form_wrapper).css({
                        'height'        : form_wrapper.height()
                    });
                    $(form_wrapper.find('form:visible')).fadeOut(400,function(){
                        form_wrapper.stop().animate({
                            height   : target_height,
                            marginTop: ( - (target_height/2) - 24)
                        },500,function(){
                            $(target).fadeIn(400);
                            $('.links_btm .linkform').toggle();
                            $(form_wrapper).css({
                                'height'        : ''
                            });
                        });
                    });
                    e.preventDefault();
                });

                //* validation
                $('#login_form').validate({
                    onkeyup: false,
                    errorClass: 'error',
                    validClass: 'valid',
                    rules: {
                        username: { required: true, minlength: 3 },
                        password: { required: true, minlength: 3 }
                    },
                    highlight: function(element) {
                        $(element).closest('div').addClass("f_error");
                        setTimeout(function() {
                            boxHeight()
                        }, 200)
                    },
                    unhighlight: function(element) {
                        $(element).closest('div').removeClass("f_error");
                        setTimeout(function() {
                            boxHeight()
                        }, 200)
                    },
                    errorPlacement: function(error, element) {
                        $(element).closest('div').append(error);
                    }
                });
            });
        </script>
</body>
</html>
