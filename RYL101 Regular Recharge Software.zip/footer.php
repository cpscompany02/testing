<div id="copyright">
        <div class="container">
            <!-- Copyright Text Start -->
            <p class="left">Copyright <?php echo date("Y"); ?> &copy; <a href="https://cpscompany.in/"><?php echo $_SERVER['SERVER_NAME'];?></a>. All Rights Reserved RoyalCode </p>
            <!-- Copyright Text End -->
          
        </div>
    </div>